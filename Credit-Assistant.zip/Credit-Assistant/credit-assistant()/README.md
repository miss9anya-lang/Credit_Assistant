# Credit Assistant — Version 1.0

Complete local MVP: React/Vite frontend + FastAPI backend + SQLite/SQLAlchemy + JWT auth + financial analytics + Recharts + Gemini AI + PDF report + loan tracking.

## Run backend (Windows PowerShell)

```powershell
cd backend
python -m venv venv
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env
uvicorn app.main:app --reload
```

Set `GEMINI_API_KEY` in `.env` for live Gemini responses. If it is blank, the AI Advisor uses a local fallback so the rest of the application still works.

Backend: http://127.0.0.1:8000
Swagger: http://127.0.0.1:8000/docs

## Run frontend

Open a second terminal:

```powershell
cd frontend
npm install
npm run dev
```

Frontend: http://localhost:5173

## Test

Register → Financial profile → Dashboard → AI Advisor → Loans → Download PDF.

Do not commit `.env`, API keys, the SQLite database, `venv`, or `node_modules`.

Educational tool only. It is not an official CIBIL service, does not guarantee lending outcomes, and does not replace professional financial advice.
