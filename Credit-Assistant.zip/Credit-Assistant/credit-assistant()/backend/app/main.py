from datetime import datetime, timedelta, timezone
from io import BytesIO
from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, EmailStr, Field
from pydantic_settings import BaseSettings, SettingsConfigDict
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, ForeignKey, Text
from sqlalchemy.orm import declarative_base, sessionmaker, Session, relationship
from jose import jwt, JWTError
from passlib.context import CryptContext
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors

class Settings(BaseSettings):
    gemini_api_key: str = ""
    secret_key: str = "change-this-secret"
    database_url: str = "sqlite:///./credit_assistant.db"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
settings=Settings()

engine=create_engine(settings.database_url, connect_args={"check_same_thread":False} if settings.database_url.startswith("sqlite") else {})
SessionLocal=sessionmaker(bind=engine,autocommit=False,autoflush=False)
Base=declarative_base()
pwd=CryptContext(schemes=["bcrypt"],deprecated="auto")
oauth=OAuth2PasswordBearer(tokenUrl="/api/auth/login")

class User(Base):
    __tablename__="users"
    id=Column(Integer,primary_key=True); name=Column(String(120),nullable=False); email=Column(String(255),unique=True,index=True,nullable=False); password_hash=Column(String(255),nullable=False); created_at=Column(DateTime,default=datetime.utcnow)
class Profile(Base):
    __tablename__="profiles"
    id=Column(Integer,primary_key=True); user_id=Column(Integer,ForeignKey("users.id"),unique=True,nullable=False)
    monthly_income=Column(Float,default=0); monthly_expenses=Column(Float,default=0); current_savings=Column(Float,default=0); monthly_emi=Column(Float,default=0); outstanding_debt=Column(Float,default=0)
    credit_score=Column(Integer,default=0); credit_limit=Column(Float,default=0); credit_used=Column(Float,default=0); missed_payments=Column(Integer,default=0); updated_at=Column(DateTime,default=datetime.utcnow,onupdate=datetime.utcnow)
class History(Base):
    __tablename__="history"
    id=Column(Integer,primary_key=True); user_id=Column(Integer,ForeignKey("users.id")); credit_score=Column(Integer); utilization=Column(Float); dti=Column(Float); health=Column(Float); recorded_at=Column(DateTime,default=datetime.utcnow)
class Loan(Base):
    __tablename__="loans"
    id=Column(Integer,primary_key=True); user_id=Column(Integer,ForeignKey("users.id")); loan_type=Column(String(100)); original_amount=Column(Float); outstanding_amount=Column(Float); monthly_emi=Column(Float); interest_rate=Column(Float); status=Column(String(30),default="Active"); created_at=Column(DateTime,default=datetime.utcnow)
class Recommendation(Base):
    __tablename__="recommendations"
    id=Column(Integer,primary_key=True); user_id=Column(Integer,ForeignKey("users.id")); question=Column(Text); answer=Column(Text); created_at=Column(DateTime,default=datetime.utcnow)

Base.metadata.create_all(engine)
app=FastAPI(title="Credit Assistant API",version="1.0.0")
app.add_middleware(CORSMiddleware,allow_origins=["http://localhost:5173"],allow_credentials=True,allow_methods=["*"],allow_headers=["*"])

def db():
    d=SessionLocal()
    try: yield d
    finally: d.close()

def token(uid):
    return jwt.encode({"sub":str(uid),"exp":datetime.now(timezone.utc)+timedelta(days=1)},settings.secret_key,algorithm="HS256")

def current(token_value:str=Depends(oauth),d:Session=Depends(db)):
    try: uid=int(jwt.decode(token_value,settings.secret_key,algorithms=["HS256"])["sub"])
    except (JWTError,TypeError,ValueError): raise HTTPException(401,"Invalid or expired token")
    u=d.get(User,uid)
    if not u: raise HTTPException(401,"User not found")
    return u

def metrics(p):
    dti=round((p.monthly_emi/p.monthly_income*100) if p.monthly_income else 0,2)
    util=round((p.credit_used/p.credit_limit*100) if p.credit_limit else 0,2)
    surplus=round(p.monthly_income-p.monthly_expenses-p.monthly_emi,2)
    health=round(
        max(0,min(40,(p.credit_score-300)/600*40))+
        (20 if util<=10 else 15 if util<=30 else 10 if util<=50 else 4 if util<=75 else 0)+
        (20 if dti<=20 else 15 if dti<=35 else 8 if dti<=50 else 0)+
        (15 if p.missed_payments==0 else 7 if p.missed_payments==1 else 0)+
        (5 if p.current_savings>=p.monthly_expenses*3 and p.current_savings>0 else 2 if p.current_savings>0 else 0),1)
    b=[]
    if util>50:b.append(["High credit utilization","High Priority"])
    elif util>30:b.append(["Credit utilization needs attention","Needs Attention"])
    if dti>50:b.append(["High debt burden","High Priority"])
    elif dti>35:b.append(["Debt burden needs attention","Needs Attention"])
    if p.missed_payments:b.append(["Payment history needs attention","High Priority"])
    if surplus<0:b.append(["Negative monthly surplus","High Priority"])
    if not b:b=[["No major bottleneck detected","Healthy"]]
    return {"dti":dti,"utilization":util,"surplus":surplus,"health":health,"bottlenecks":b}

class Register(BaseModel):
    name:str=Field(min_length=2,max_length=120); email:EmailStr; password:str=Field(min_length=8,max_length=128)
class Login(BaseModel): email:EmailStr; password:str
class ProfileIn(BaseModel):
    monthly_income:float=Field(ge=0); monthly_expenses:float=Field(ge=0); current_savings:float=Field(ge=0); monthly_emi:float=Field(ge=0); outstanding_debt:float=Field(ge=0)
    credit_score:int=Field(ge=300,le=900); credit_limit:float=Field(ge=0); credit_used:float=Field(ge=0); missed_payments:int=Field(ge=0)
class LoanIn(BaseModel):
    loan_type:str; original_amount:float=Field(ge=0); outstanding_amount:float=Field(ge=0); monthly_emi:float=Field(ge=0); interest_rate:float=Field(ge=0,le=100); status:str="Active"
class Ask(BaseModel): question:str=Field(min_length=3,max_length=2000)

@app.get("/")
def root(): return {"message":"Credit Assistant API is running"}
@app.get("/api/health")
def health(): return {"status":"healthy","service":"Credit Assistant API"}

@app.post("/api/auth/register")
def register(x:Register,d:Session=Depends(db)):
    if d.query(User).filter(User.email==x.email.lower()).first(): raise HTTPException(400,"Email already registered")
    u=User(name=x.name.strip(),email=x.email.lower(),password_hash=pwd.hash(x.password)); d.add(u); d.commit(); d.refresh(u); d.add(Profile(user_id=u.id)); d.commit()
    return {"access_token":token(u.id),"token_type":"bearer"}

@app.post("/api/auth/login")
def login(x:Login,d:Session=Depends(db)):
    u=d.query(User).filter(User.email==x.email.lower()).first()
    if not u or not pwd.verify(x.password,u.password_hash): raise HTTPException(401,"Invalid email or password")
    return {"access_token":token(u.id),"token_type":"bearer"}

@app.get("/api/users/me")
def me(u=Depends(current)): return {"id":u.id,"name":u.name,"email":u.email}

@app.get("/api/profile")
def get_profile(u=Depends(current),d:Session=Depends(db)):
    return d.query(Profile).filter(Profile.user_id==u.id).first().__dict__ | {}

@app.put("/api/profile")
def update_profile(x:ProfileIn,u=Depends(current),d:Session=Depends(db)):
    p=d.query(Profile).filter(Profile.user_id==u.id).first()
    if x.credit_limit and x.credit_used>x.credit_limit: raise HTTPException(400,"Credit used cannot exceed credit limit")
    for k,v in x.model_dump().items(): setattr(p,k,v)
    m=metrics(p); d.add(History(user_id=u.id,credit_score=p.credit_score,utilization=m["utilization"],dti=m["dti"],health=m["health"])); d.commit(); d.refresh(p)
    return p.__dict__ | {}

@app.get("/api/dashboard")
def dashboard(u=Depends(current),d:Session=Depends(db)):
    p=d.query(Profile).filter(Profile.user_id==u.id).first(); m=metrics(p)
    hs=d.query(History).filter(History.user_id==u.id).order_by(History.recorded_at).all()
    return {"user":{"name":u.name,"email":u.email},"profile":{k:getattr(p,k) for k in ["monthly_income","monthly_expenses","current_savings","monthly_emi","outstanding_debt","credit_score","credit_limit","credit_used","missed_payments"]},"metrics":m,"history":[{"date":h.recorded_at.strftime("%Y-%m-%d"),"credit_score":h.credit_score,"utilization":h.utilization,"dti":h.dti,"health":h.health} for h in hs]}

@app.get("/api/loans")
def loans(u=Depends(current),d:Session=Depends(db)):
    return [x.__dict__ | {} for x in d.query(Loan).filter(Loan.user_id==u.id).order_by(Loan.created_at.desc()).all()]
@app.post("/api/loans")
def add_loan(x:LoanIn,u=Depends(current),d:Session=Depends(db)):
    l=Loan(user_id=u.id,**x.model_dump()); d.add(l); d.commit(); d.refresh(l); return l.__dict__ | {}
@app.delete("/api/loans/{lid}")
def del_loan(lid:int,u=Depends(current),d:Session=Depends(db)):
    l=d.query(Loan).filter(Loan.id==lid,Loan.user_id==u.id).first()
    if not l: raise HTTPException(404,"Loan not found")
    d.delete(l);d.commit();return {"message":"Loan deleted"}

def fallback(p,m,q):
    return f"""## Credit Health Summary
Your tracked credit score is {p.credit_score}. Your credit utilization is {m['utilization']}% and your debt-to-income ratio is {m['dti']}%.

## Key Bottlenecks
The dashboard currently flags: {", ".join(x[0] for x in m["bottlenecks"])}.

## 5-Step Action Plan
1. Make payments on time and keep due dates organized.
2. Keep revolving credit utilization controlled where practical.
3. Review EMI and outstanding debt before taking new borrowing.
4. Maintain a cash buffer for essential expenses.
5. Track your credit profile after meaningful financial changes.

## Things to Monitor
Utilization, EMI burden, missed payments, monthly surplus and credit-score changes.

## Important Considerations
This is educational guidance, not an official CIBIL assessment or a guarantee of lending outcomes.

Question: {q}"""

@app.post("/api/advisor")
def advisor(x:Ask,u=Depends(current),d:Session=Depends(db)):
    p=d.query(Profile).filter(Profile.user_id==u.id).first()
    if not p or not p.credit_score: raise HTTPException(400,"Complete your financial profile first")
    m=metrics(p)
    try:
        if settings.gemini_api_key:
            from google import genai
            from google.genai import types
            client=genai.Client(api_key=settings.gemini_api_key)
            prompt=f"""User metrics: credit score {p.credit_score}; income ₹{p.monthly_income}; expenses ₹{p.monthly_expenses}; EMI ₹{p.monthly_emi}; debt ₹{p.outstanding_debt}; savings ₹{p.current_savings}; utilization {m['utilization']}%; DTI {m['dti']}%; missed payments {p.missed_payments}. User question: {x.question}"""
            r=client.models.generate_content(model="gemini-3.8-flash",contents=prompt,config=types.GenerateContentConfig(system_instruction="You are Credit Assistant, an educational financial wellness advisor for India. Give a concise summary, key bottlenecks, a 5-step plan, habits to improve, things to monitor and cautions. Do not claim to provide an official CIBIL score or guarantee lending outcomes. Do not invent data.",temperature=.4,max_output_tokens=1000))
            answer=r.text or fallback(p,m,x.question)
        else: answer=fallback(p,m,x.question)
    except Exception as e: raise HTTPException(502,f"AI Advisor unavailable: {str(e)[:160]}")
    d.add(Recommendation(user_id=u.id,question=x.question,answer=answer));d.commit()
    return {"answer":answer}

@app.get("/api/advisor/history")
def advisor_history(u=Depends(current),d:Session=Depends(db)):
    return [{"question":r.question,"answer":r.answer,"created_at":r.created_at} for r in d.query(Recommendation).filter(Recommendation.user_id==u.id).order_by(Recommendation.created_at.desc()).limit(10)]

@app.get("/api/reports/pdf")
def pdf(u=Depends(current),d:Session=Depends(db)):
    p=d.query(Profile).filter(Profile.user_id==u.id).first();m=metrics(p)
    h=d.query(History).filter(History.user_id==u.id).order_by(History.recorded_at).all()
    b=BytesIO();doc=SimpleDocTemplate(b,pagesize=A4); story=[Paragraph("Credit Assistant",__import__("reportlab.lib.styles",fromlist=["getSampleStyleSheet"]).getSampleStyleSheet()["Title"]),Paragraph("Financial Health Report",__import__("reportlab.lib.styles",fromlist=["getSampleStyleSheet"]).getSampleStyleSheet()["Heading2"]),Spacer(1,15)]
    rows=[["Metric","Value"],["Credit Score",str(p.credit_score)],["Financial Health",f"{m['health']}/100"],["DTI",f"{m['dti']}%"],["Utilization",f"{m['utilization']}%"],["Income",f"₹{p.monthly_income:,.0f}"],["Expenses",f"₹{p.monthly_expenses:,.0f}"],["EMI",f"₹{p.monthly_emi:,.0f}"],["Debt",f"₹{p.outstanding_debt:,.0f}"],["Savings",f"₹{p.current_savings:,.0f}"],["Missed Payments",str(p.missed_payments)]]
    t=Table(rows,colWidths=[230,230]);t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#111827")),("TEXTCOLOR",(0,0),(-1,0),colors.white),("GRID",(0,0),(-1,-1),.4,colors.grey),("PADDING",(0,0),(-1,-1),7)]));story+=[t,Spacer(1,15),Paragraph("Bottlenecks",__import__("reportlab.lib.styles",fromlist=["getSampleStyleSheet"]).getSampleStyleSheet()["Heading2"])]
    for title,severity in m["bottlenecks"]: story.append(Paragraph(f"<b>{severity}</b>: {title}",__import__("reportlab.lib.styles",fromlist=["getSampleStyleSheet"]).getSampleStyleSheet()["BodyText"]))
    story += [Spacer(1,15),Paragraph("Credit History",__import__("reportlab.lib.styles",fromlist=["getSampleStyleSheet"]).getSampleStyleSheet()["Heading2"])]
    hr=[["Date","Score","Utilization","DTI","Health"]]+[[x.recorded_at.strftime("%d %b %Y"),str(x.credit_score),f"{x.utilization:.1f}%",f"{x.dti:.1f}%",f"{x.health:.1f}"] for x in h[-12:]]
    ht=Table(hr,colWidths=[95,70,90,70,80]);ht.setStyle(TableStyle([("GRID",(0,0),(-1,-1),.4,colors.grey),("BACKGROUND",(0,0),(-1,0),colors.lightgrey),("PADDING",(0,0),(-1,-1),5)]));story += [ht,Spacer(1,15),Paragraph("Educational tool only. Not an official CIBIL service or lending decision.",__import__("reportlab.lib.styles",fromlist=["getSampleStyleSheet"]).getSampleStyleSheet()["BodyText"])]
    doc.build(story);b.seek(0);return StreamingResponse(b,media_type="application/pdf",headers={"Content-Disposition":"attachment; filename=credit-assistant-report.pdf"})
